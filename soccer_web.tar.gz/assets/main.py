import pygame
import sys
import random
import asyncio  # Required for web version

# --- Configuration ---
WIDTH, HEIGHT = 900, 600
FPS = 60
GOAL_SIZE = 180
WIN_SCORE = 5

# Colors
GREEN = (34, 139, 34)
WHITE = (255, 255, 255)
RED = (200, 0, 0)
BLUE = (0, 0, 200)
BLACK = (0, 0, 0)
GOLD = (255, 215, 0)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Web-Ready Soccer")
clock = pygame.time.Clock()
font = pygame.font.SysFont("Arial", 36, bold=True)
small_font = pygame.font.SysFont("Arial", 24)

# --- Classes (Same as before) ---
class Player:
    def __init__(self, x, y, color, controls, kick_key):
        self.rect = pygame.Rect(x, y, 45, 45)
        self.color = color
        self.controls = controls 
        self.kick_key = kick_key
        self.speed = 6
        self.score = 0
        self.is_kicking = False
        self.ai_target_y = y
        self.reaction_timer = 0

    def move(self, keys, ball=None, is_ai=False):
        if is_ai and ball:
            self.reaction_timer += 1
            if self.reaction_timer > 15:
                self.ai_target_y = ball.pos.y + random.randint(-20, 20)
                self.reaction_timer = 0
            if self.rect.centery < self.ai_target_y - 10: self.rect.y += self.speed - 1
            elif self.rect.centery > self.ai_target_y + 10: self.rect.y -= self.speed - 1
            target_x = WIDTH - 120 if ball.pos.x < WIDTH * 0.7 else ball.pos.x - 40
            if self.rect.x < target_x: self.rect.x += 2
            elif self.rect.x > target_x: self.rect.x -= 2
            self.is_kicking = ball.pos.distance_to(pygame.Vector2(self.rect.center)) < 60
        else:
            if keys[self.controls[0]] and self.rect.top > 0: self.rect.y -= self.speed
            if keys[self.controls[1]] and self.rect.bottom < HEIGHT: self.rect.y += self.speed
            if keys[self.controls[2]] and self.rect.left > 0: self.rect.x -= self.speed
            if keys[self.controls[3]] and self.rect.right < WIDTH: self.rect.x += self.speed
            self.is_kicking = keys[self.kick_key]

    def draw(self):
        color = (255, 255, 255) if self.is_kicking else self.color
        pygame.draw.rect(screen, color, self.rect, border_radius=5)

BALL_FRICTION = 0.995       # Applied every frame — ball gradually slows
BALL_MIN_SPEED = 0.3        # Below this, ball stops completely
KICK_SPEED_BOOST = 3.0      # Extra speed added on spacebar kick
BALL_BASE_SPEED = 5.0       # Normal deflection speed off a player

class Ball:
    def __init__(self):
        self.radius = 12
        self.reset()

    def reset(self):
        self.pos = pygame.Vector2(WIDTH // 2, HEIGHT // 2)
        self.vel = pygame.Vector2(random.choice([-4, 4]), random.uniform(-2, 2))

    def update(self):
        # Apply friction — ball loses momentum over time
        self.vel *= BALL_FRICTION
        if self.vel.length() < BALL_MIN_SPEED:
            self.vel = pygame.Vector2(0, 0)

        self.pos += self.vel
        if self.pos.y - self.radius <= 0:
            self.pos.y = self.radius
            self.vel.y *= -1
        if self.pos.y + self.radius >= HEIGHT:
            self.pos.y = HEIGHT - self.radius
            self.vel.y *= -1

    def draw(self):
        pygame.draw.circle(screen, WHITE, (int(self.pos.x), int(self.pos.y)), self.radius)
        pygame.draw.circle(screen, BLACK, (int(self.pos.x), int(self.pos.y)), self.radius, 2)

# --- Helper Functions ---
def check_win(s1, s2):
    if s1 >= WIN_SCORE and (s1 - s2) >= 2: return "RED WINS!"
    if s2 >= WIN_SCORE and (s2 - s1) >= 2: return "BLUE WINS!"
    return None

def show_menu():
    screen.fill(BLACK)
    title = font.render("PYTHON SOCCER", True, WHITE)
    opt1 = small_font.render("Press 1 for Single Player (vs AI)", True, GREEN)
    opt2 = small_font.render("Press 2 for Two Players", True, GREEN)
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 200))
    screen.blit(opt1, (WIDTH // 2 - opt1.get_width() // 2, 300))
    screen.blit(opt2, (WIDTH // 2 - opt2.get_width() // 2, 350))

# --- The Main Loop (Asynchronous for Web) ---
async def main():
    p1 = Player(100, HEIGHT // 2, RED, [pygame.K_w, pygame.K_s, pygame.K_a, pygame.K_d], pygame.K_SPACE)
    p2 = Player(WIDTH - 145, HEIGHT // 2, BLUE, [pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT], pygame.K_RSHIFT)
    ball = Ball()
    game_mode = None 
    winner = None
    goal_top, goal_bottom = (HEIGHT - GOAL_SIZE) // 2, (HEIGHT + GOAL_SIZE) // 2

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if game_mode is None:
                    if event.key == pygame.K_1: game_mode = 1
                    if event.key == pygame.K_2: game_mode = 2
                if winner and event.key == pygame.K_r:
                    p1.score, p2.score, winner, game_mode = 0, 0, None, None
                    ball.reset()

        if game_mode is not None and not winner:
            keys = pygame.key.get_pressed()
            p1.move(keys); p2.move(keys, ball, is_ai=(game_mode == 1))
            ball.update()
            
            # Physics & Goals
            for p in [p1, p2]:
                ball_rect = pygame.Rect(ball.pos.x - ball.radius, ball.pos.y - ball.radius,
                                        ball.radius * 2, ball.radius * 2)
                if p.rect.colliderect(ball_rect):
                    # Closest point on the player's rectangle to the ball's center.
                    # Using the rect's CENTER (old code) to measure direction/push-out
                    # undershoots near corners: it treats the square player like an
                    # inscribed circle of radius (side/2), but a corner is actually
                    # ~1.4x farther away. That gap meant the ball was sometimes pushed
                    # out to a spot that was still overlapping the player, so the very
                    # next frame re-triggered the same collision and re-snapped the
                    # ball right back next to the player every frame -- looking like
                    # the ball was stuck/glued to it, especially while the player kept
                    # moving toward the ball. Measuring from the nearest edge point
                    # instead is correct for every approach angle, including corners.
                    closest_x = max(p.rect.left, min(ball.pos.x, p.rect.right))
                    closest_y = max(p.rect.top, min(ball.pos.y, p.rect.bottom))
                    closest_point = pygame.Vector2(closest_x, closest_y)

                    diff = ball.pos - closest_point
                    if diff.length() == 0:
                        # Ball center exactly inside the rect (rare) -- fall back to
                        # pushing away from the player's center.
                        diff = ball.pos - pygame.Vector2(p.rect.center)
                        if diff.length() == 0:
                            diff = pygame.Vector2(1, 0)
                    direction = diff.normalize()

                    # Set speed: base + kick boost if player is kicking
                    speed = BALL_BASE_SPEED
                    if p.is_kicking:
                        speed += KICK_SPEED_BOOST
                    ball.vel = direction * speed

                    # Push the ball fully outside the player, measured from the
                    # nearest edge point so it clears the rect on every angle.
                    ball.pos = closest_point + direction * (ball.radius + 2)
            
            if ball.pos.x < 0:
                if goal_top < ball.pos.y < goal_bottom: p2.score += 1; ball.reset(); winner = check_win(p1.score, p2.score)
                else: ball.vel.x *= -1; ball.pos.x = 12
            elif ball.pos.x > WIDTH:
                if goal_top < ball.pos.y < goal_bottom: p1.score += 1; ball.reset(); winner = check_win(p1.score, p2.score)
                else: ball.vel.x *= -1; ball.pos.x = WIDTH - 12

        # Rendering
        if game_mode is None: show_menu()
        else:
            screen.fill(GREEN)
            pygame.draw.line(screen, WHITE, (WIDTH//2, 0), (WIDTH//2, HEIGHT), 2)
            pygame.draw.rect(screen, BLACK, (0, goal_top, 10, GOAL_SIZE))
            pygame.draw.rect(screen, BLACK, (WIDTH-10, goal_top, 10, GOAL_SIZE))
            p1.draw(); p2.draw(); ball.draw()
            score_txt = font.render(f"{p1.score} - {p2.score}", True, WHITE)
            screen.blit(score_txt, (WIDTH//2 - score_txt.get_width()//2, 20))
            if winner:
                res_txt = font.render(winner, True, GOLD)
                screen.blit(res_txt, (WIDTH//2 - res_txt.get_width()//2, HEIGHT//2 - 50))

        pygame.display.flip()
        await asyncio.sleep(0) # THIS IS THE KEY FOR THE WEB VERSION
        clock.tick(FPS)

# Start the game
asyncio.run(main())